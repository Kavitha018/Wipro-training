﻿using CalculatorLib;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CalculatorLib.Tests
{
    [TestClass]
    public class CalculatorTests
    {
        private Calculator calc;

        [TestInitialize]
        public void Setup()
        {
            calc = new Calculator();
        }

        [TestMethod]
        public void TestAddition() => Assert.AreEqual(5, calc.Add(2, 3));

        [TestMethod]
        public void TestSubtraction() => Assert.AreEqual(1, calc.Subtract(3, 2));

        [TestMethod]
        public void TestMultiplication() => Assert.AreEqual(6, calc.Multiply(2, 3));

        [TestMethod]
        [ExpectedException(typeof(DivideByZeroException))]
        public void TestDivideByZero() => calc.Divide(5, 0);

        [TestMethod]
        public void TestDivision() => Assert.AreEqual(2, calc.Divide(6, 3));
    }
}
